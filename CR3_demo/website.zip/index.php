<html>
<head>
    <style>
body {
    background-color: #262f3f; 
    color:white;
    margin: 30px;
}
h1   {
    color: rgb(241, 154, 154);
    text-align: center;
}
table {
    width: 100%;
}
.img2 {
    max-width: 100%;
}
#hostname {
    color: yellow;
}

    </style>
</head>
<body>
    <table>
    <tr>
        <td>
            <img src="AWS_logo.jpg" alt="logo" style="width: 100px; height: auto"></img>
        </td>
        <td>
            <h1>Terraform for AWS - demo - Check-Ride</h1>          
        </td>
    </tr>
    </table>
    <p>
    Note: This web page is served by server <span id="hostname"><?php echo gethostname(); ?></span>
    <p>
    <img src="arch_diagram.png" alt="diagram" class="img2"></img>
</body>
</html>