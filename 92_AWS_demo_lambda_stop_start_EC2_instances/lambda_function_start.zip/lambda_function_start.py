import boto3
import os

# region = 'eu-west-1'
# instances = ['i-04f9b09d4633b8efe', 'i-023d40b01948e7a2a']

region = os.environ['REGION']
ec2 = boto3.client('ec2', region_name=region)

def lambda_handler(event, context):
    instance_ids_str = os.environ['INSTANCE_IDS']
    instance_ids = instance_ids_str.split(",")
    ec2.start_instances(InstanceIds=instance_ids)
    print('started your instances: ' + instance_ids_str)